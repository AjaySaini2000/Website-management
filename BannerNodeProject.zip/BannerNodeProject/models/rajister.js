const mongoose=require('mongoose')



const rajisterSchema=mongoose.Schema({
    username:String,
    password:String,
    posteddate:{
        type:Date,
        default:new Date()
    }
})


module.exports=mongoose.model('userdata',rajisterSchema)