const mongoose=require('mongoose')


const querySchema=mongoose.Schema({
    Email:{
        type:String,
        required:true
    },
    Query:{
        type:String,
        required:true
    },
    postedDate:{
        type:Date,
        default:new Date(),
        required:true
    },
    action:{
        type:String,
        default:'reply',
        required:true
    }
})

module.exports=mongoose.model('query',querySchema)