const mongoose=require('mongoose')


const bannerSchema=mongoose.Schema({
    btitle:{
        type:String,
        required:true
    },
    bdesc:{
        type:String,
        required:true
    },
    bmdetail:{
        type:String,
        required:true
    },
    bimage:{
        type:String,
        required:true
    }

})
module.exports=mongoose.model('bannerdata',bannerSchema)