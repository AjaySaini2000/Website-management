const mongoose=require('mongoose')

const testinominalSchema=mongoose.Schema({
    quotes:{
        type:String,
        require:true
    },
    user:{
        type:String,
        require:true
    },
    image:{
        type:String
    },
    postedDate:{
        type:Date,
        default:new Date()
    },
    status:{
        type:String,
        default:'Unpublished'
    }
})
module.exports=mongoose.model('testinominaldata',testinominalSchema)