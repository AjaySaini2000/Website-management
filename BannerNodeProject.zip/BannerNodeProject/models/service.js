const mongoose=require('mongoose')

const serviceSchema=mongoose.Schema({
    stitle:{
        type:String,
        recuired:true
    },
    sdesc:{
        type:String,
        recuired:true
    },
    smdetail:{
        type:String,
        required:true
    },
    image:{
        type:String,

    },
    postedDate:{
        type:Date,
        default:Date.now()

    },
    status:{
        type:String,
        default:'Unpublished'
    }
})
module.exports=mongoose.model('servicedata',serviceSchema)