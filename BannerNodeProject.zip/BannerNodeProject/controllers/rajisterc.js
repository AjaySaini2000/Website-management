const rajisterTable = require('../models/rajister')


exports.loginshow = (req, res) => {
    let error = ''
    res.render('admin/login.ejs', { error })
}
exports.logincheck = async (req, res) => {
    // console.log(req.body)
    const { username, password } = req.body
    if(username=='' || password==''){
        let error = 'Please fill the username & password'
        res.render('admin/login.ejs', { error })
    }else{
    const usercheck = await rajisterTable.findOne({ username: username })
    // console.log(usercheck)
    if (usercheck != null) {

        if (usercheck.password == password) {
            req.session.isAuth=true
            req.session.username=username
            res.redirect('/admin/dashboard')
        }
        else {
            let error = 'Wrong Password'
            res.render('admin/login.ejs', { error })
        }
    }
    else {
        let error = 'Please make registrtion.'
        res.render('admin/login.ejs', { error })
    }
}
}
exports.dashboard=(req,res)=>{
    const adminName=req.session.username
    res.render('admin/dashboard.ejs',{adminName})
}
exports.logout=(req,res)=>{
    req.session.destroy()
    res.redirect('/admin/')
}