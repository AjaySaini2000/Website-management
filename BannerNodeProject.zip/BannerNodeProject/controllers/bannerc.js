const bannerTable=require('../models/banner')


exports.bannermanage=async(req,res)=>{
    const adminName=req.session.username
    const bannerdata=await bannerTable.findOne()
    // console.log(bannerdata)
    res.render('admin/banner.ejs',{adminName,bannerdata})
}
exports.update=async(req,res)=>{
    const adminName=req.session.username
    const id=req.params.id
    const bannerdata=await bannerTable.findById(id)
    let message=''
        let color=''
   res.render('admin/bannerupdate.ejs',{adminName,bannerdata,message,color})
 }
 exports.updated=async(req,res)=>{
    const id=req.params.id
    //    console.log(req.body)
    const{title,desc,mdetail}=req.body 
    
    const adminName=req.session.username
        const bannerdata=await bannerTable.findById(id)
        let message=null
        let color=null

    if(title==''){
        
         message='please fill the banner title'
         color='danger'
        
    }else if(desc==''){
        
         message='please fill the banner description'
     color='danger'
       
    }
    else if(mdetail==''){
       
         message='please fill the banner moredetails'
         color='danger'
        
    }else if(req.file){
        const file=req.file
        await bannerTable.findByIdAndUpdate(id,({btitle:title,bdesc:desc,bmdetail:mdetail,bimage:file.filename}))
    
    } else{
    await bannerTable.findByIdAndUpdate(id,({btitle:title,bdesc:desc,bmdetail:mdetail}))
    
         message='Successfully Update'
         color='success'
       
   
    }
    res.render('admin/bannerupdate.ejs',{message,color,adminName,bannerdata})
}


    exports.bmdetail=async(req,res)=>{
        const bannerData=await bannerTable.findOne()
        res.render('bmoredetail.ejs',{bannerData})
    }