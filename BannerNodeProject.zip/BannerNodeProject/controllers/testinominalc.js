const testinominalTable=require('../models/testinominal')

exports.testiform=(req,res)=>{
    res.render('testinominalform.ejs')
}
exports.testiformdata=(req,res)=>{
    const{Quotes,name}=req.body
    const file=req.file
   const newRecord=new testinominalTable({quotes:Quotes,user:name,image:file.filename})
   newRecord.save()
}
exports.testinominaldata=async(req,res)=>{
    // console.log('hello')
    const adminName=req.session.username
    const data=await testinominalTable.find().sort({status:+1})
    // console.log(data)
    res.render('./admin/testinominals.ejs',{adminName,data})
}
exports.deletetestiservice=async(req,res)=>{
    const id=req.params.id
    // console.log(id)
    await testinominalTable.findByIdAndDelete(id)
    res.redirect('/admin/testinominals/')
    
    }


    exports.testistatus=async(req,res)=>{
        const id=req.params.id
        const testiData=await testinominalTable.findById(id)
        let newStaus=null
        if(testiData.status=='Unpublished'){
            newStaus='published'
        }else{
            newStaus='Unpublished'
        }
        await testinominalTable.findByIdAndUpdate(id,{status:newStaus})
        res.redirect('/admin/testinominals/')
        }