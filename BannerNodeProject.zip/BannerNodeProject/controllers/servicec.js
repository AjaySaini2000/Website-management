const serviceTable=require('../models/service')
let message=''
let color=''

exports.service=async(req,res)=>{
    const adminName=req.session.username
    
    message=req.params.mess
    const countService=await serviceTable.find().count()
    const countPublished=await serviceTable.find({status:'published'}).count()
    const countUnpublished=await serviceTable.find({status:'Unpublished'}).count()
    // console.log(countUnpublished)
    if(req.params.mess=='mess'){
        var servicedata=await serviceTable.find().sort({status:+1})
    }
    else if(req.params.mess=='search'){
        var servicedata=await serviceTable.find({status:req.query.search}).sort({status:+1})
    }
    else{
        var servicedata=await serviceTable.find()
    }
    
    res.render('admin/services.ejs',{adminName,servicedata,message,countService,countPublished,countUnpublished})
}
exports.serviceForm=(req,res)=>{
    const adminName=req.session.username
    
    res.render('admin/servicesform.ejs',{adminName,message})
}

exports.serviceData=(req,res)=>{
    const adminName=req.session.username
    const{servicetitle,serviceDescrip,servicemdetail}=req.body
    const file=req.file
    if(servicetitle==''){
        message='please fill servicetitle'
        
    }else if(serviceDescrip==''){
        message='please fill servicedescription'
        
    }else if(servicemdetail==''){
        message='please fill servicemdetail'
        
    }else{
    const newRecord=new serviceTable({stitle:servicetitle,sdesc:serviceDescrip,smdetail:servicemdetail,image:file.filename})
    newRecord.save()
    message='successfully add data'
    }
    res.redirect(`/admin/services/${message}`)
}
exports.delete=async(req,res)=>{
    const id=req.params.id
    await serviceTable.findByIdAndDelete(id)
    message='successfully deleted'
    res.redirect(`/admin/services/${message}`)
    

}
exports.serviceStatus=async(req,res)=>{
    const id=req.params.id
    const data=await serviceTable.findById(id)
    let newStatus=null
    if(data.status=='Unpublished'){
        newStatus='published'
    }else{
        newStatus='Unpublished'
    }
    await serviceTable.findByIdAndUpdate(id,{status:newStatus})
    res.redirect('/admin/services/mess')

}
exports.servicemdetail=async(req,res)=>{
    const id=req.params.id
    const serviceData=await serviceTable.findById(id)
    res.render('servicemoredetail.ejs',{serviceData})
}