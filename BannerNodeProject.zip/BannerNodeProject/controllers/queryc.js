const queryTable=require('../models/query')
const nodemailer=require('nodemailer')



exports.queryform=(req,res)=>{
    const{email,query}=req.body
    const newRecord=new queryTable({Email:email,Query:query})
    newRecord.save()
    res.redirect('/')
}
exports.queryformdata=async(req,res)=>{
    const adminName=req.session.username
    const data=await queryTable.find().sort({action:-1})
    res.render('admin/query.ejs',{data,adminName})
    
}

exports.querydelete=async(req,res)=>{
    const id=req.params.id
    await queryTable.findByIdAndDelete(id)
    res.redirect('/admin/queries/')
}

exports.queryReply=async(req,res)=>{
    const adminName=req.session.username
    const id=req.params.id
    const data=await queryTable.findById(id)
    
    res.render('admin/queryreply.ejs',{adminName,data})
}
exports.sendmail=async(req,res)=>{
    const{emailto,emailfrom,sub,body}=req.body
    const id=req.params.id
    
    const transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 587,
        secure: false,
        auth: {
          // TODO: replace `user` and `pass` values from <https://forwardemail.net>
          user: "ajayexpress2000@gmail.com",
          pass: "xtlsimkhzfvuoqhv",
        },
      });
      if(req.file){
        const filepath=req.file.path
        await transporter.sendMail({
            from: emailfrom, // sender address
            to: emailto, // list of receivers
            subject: sub+"Hello ✔", // Subject line
            text: body,
            attachments:[{
                path:filepath
            }] // plain text body
            // html: body, // html body
          });
      }else{
        await transporter.sendMail({
            from: emailfrom, // sender address
            to: emailto, // list of receivers
            subject: sub+"Hello ✔", // Subject line
            text: body // plain text body
            // html: body, // html body
          });
      }
     
      console.log('connected to smtp server')
     
      await queryTable.findByIdAndUpdate(id,{action:'replied'})
      res.redirect('/admin/queries/')
}