const router=require('express').Router()
const rajistercontroller=require('../../controllers/rajisterc')
const bannercontroller=require('../../controllers/bannerc')
const servicecontroller=require('../../controllers/servicec')
const testinominalcontroller=require('../../controllers/testinominalc')
const querycontroller=require('../../controllers/queryc')



const multer=require('../../helpers/multer')


const handlelogin=require('../../midleware/logincheck')

router.get('/',rajistercontroller.loginshow)
router.post('/',rajistercontroller.logincheck)
router.get('/dashboard',handlelogin,rajistercontroller.dashboard)
router.get('/logout',rajistercontroller.logout)
router.get('/banner',handlelogin,bannercontroller.bannermanage)
router.get('/update/:id',handlelogin,bannercontroller.update)
router.post('/update/:id',handlelogin,multer.single('img'),bannercontroller.updated)
router.get('/services/:mess',servicecontroller.service)



router.get('/serviceform',servicecontroller.serviceForm)
router.post('/serviceform',multer.single('image'),servicecontroller.serviceData)
router.get('/deleteservice/:id',servicecontroller.delete)

router.get('/servicestatus/:id',servicecontroller.serviceStatus)
router.get('/testinominals',testinominalcontroller.testinominaldata)
router.get('/deletetestiservice/:id',testinominalcontroller.deletetestiservice)
router.get('/testinominalstatus/:id',testinominalcontroller.testistatus)
router.get('/queries',querycontroller.queryformdata)
router.get('/deletequery/:id',querycontroller.querydelete)
router.get('/queryreply/:id',querycontroller.queryReply)
router.post('/queryreply/:id',multer.single('attachment'),querycontroller.sendmail)

module.exports=router