const router=require('express').Router()
const rajistercontroller=require('../controllers/rajisterc')
const bannercontroller=require('../controllers/bannerc')
const servicecontroller=require('../controllers/servicec')
const testinominalcontroller=require('../controllers/testinominalc')
const querycontroller=require('../controllers/queryc')


const bannerTable=require('../models/banner')
const serviceTable=require('../models/service')
const testinominalTable=require('../models/testinominal')
// const queryTable=require('../models/query')

const multer=require('../helpers/multer')



router.get('/',async(req,res)=>{
    const bannerData=await bannerTable.findOne()
    const serviceData=await serviceTable.find({status:'published'})
    const testinominalData=await testinominalTable.find({status:'published'})
    // console.log(serviceData)
    
    res.render('project1.ejs',{bannerData,serviceData,testinominalData})
})
router.get('/bannermoredetail',bannercontroller.bmdetail)
router.get('/servicemoredetail/:id',servicecontroller.servicemdetail)
router.get('/testinominalform',testinominalcontroller.testiform)
router.post('/testinominalform',multer.single('img'),testinominalcontroller.testiformdata)
router.post('/query',querycontroller.queryform)


module.exports=router